package Practice.Sol6;

import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        InventoryManagement mt = new InventoryManagement();
        while(true){
            System.out.println("1.Add product\n2.Display All products\n3.Display by Id\n4.Update product price\n5.Update product quantity\n6.delete by id\n7.exit\n");
            int n = sc.nextInt();
            switch(n){
                case 1:
                    System.out.println("Enter id:");
                    int id = sc.nextInt();
                    System.out.println("Enter product name:");
                    String name = sc.next();
                    System.out.println("Enter Price");
                    double price = sc.nextDouble();
                    System.out.println("Enter Quantity");
                    int qty = sc.nextInt();
                    Product p = new Product(id,name,price,qty);
                    mt.addproduct(p);
                    break;
                case 2:
                    System.out.println("Displaying all products");
                    mt.displayAllProducts();
                    break;

                case 7:
                    System.out.println("Exiting......");
                    return;
                default:
                    System.out.println("Enter number from 1 - 6");
            }
        }
    }
}
